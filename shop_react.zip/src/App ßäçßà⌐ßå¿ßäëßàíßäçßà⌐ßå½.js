import { AgGridReact } from "ag-grid-react";
import { useState, useEffect, useRef } from "react";
import * as echarts from "echarts";
import "bootstrap/dist/css/bootstrap.min.css";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import data from "./data.js";
import { Button } from "react-bootstrap";

function App() {
  const [gridApi, setGridApi] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const chartRef = useRef(null); // ✅ ECharts 컨테이너 참조
  const [rowData, setRowData] = useState();
  const currentWeek = 3; // ✅ 현재 주차 (4주차)
  const columnDefs = [
    {
      field: "CATEGORY1",
      headerName: "Category1",
      editable: true,
      minWidth: 100,
      pinned: "left",
    },
    {
      field: "CATEGORY2",
      headerName: "Category2",
      editable: true,
      minWidth: 100,
      pinned: "left",
    },
    {
      field: "FINAL_TARGET",
      headerName: "Final Target(최근)",
      editable: false,
      minWidth: 100,
      pinned: "left",
      valueGetter: (params) => {
        // ✅ 가장 마지막으로 입력된 Target 값 찾기
        const weeks = Array.from(
          { length: 10 },
          (_, i) => `WW${10 - i}_TARGET`
        );
        for (let week of weeks) {
          if (params.data[week] !== undefined && params.data[week] !== null) {
            return params.data[week]; // 마지막 입력된 Target 값 반환
          }
        }
        return null; // 아무 값도 없으면 null 반환
      },
      cellStyle: { color: "blue", fontweight: "bold" },
    },

    {
      headerName: "Week",
      children: Array.from({ length: 10 }, (_, i) => ({
        headerName: `${i + 1}`,
        children: [
          {
            field: `WW${i + 1}_TARGET`,
            headerName: "Target",
            editable: (params) => i + 1 >= currentWeek, // ✅ 4주차부터 편집 가능
            minWidth: 40,
            cellStyle: (params) =>
              i + 1 < currentWeek
                ? {
                    backgroundColor: "lightgray",
                    color: "darkgray",
                    pointerEvents: "none",
                  } // ✅ 4주차 이전 비활성화
                : {},
          },
          {
            field: `WW${i + 1}_RESULT`,
            headerName: "Result",
            editable: (params) => i + 1 >= currentWeek, // ✅ 4주차부터 편집 가능
            minWidth: 40,
            cellStyle: (params) =>
              i + 1 < currentWeek
                ? {
                    backgroundColor: "lightgray",
                    color: "darkgray",
                    pointerEvents: "none",
                  } // ✅ 4주차 이전 비활성화
                : {},
          },
        ],
      })),
    },
    {
      field: "REMARKS",
      headerName: "비고",
      editable: true,
      minWidth: 150,
      flex: 1, // ✅ 다른 컬럼과 동일한 `flex` 적용
      maxWidth: 300, // ✅ 비고 컬럼이 너무 길어지지 않도록 제한
    },
  ];

  const onGridReady = (params) => {
    setGridApi(params.api);

    setTimeout(() => {
      if (params.api && params.columnApi) {
        console.log("✅ Grid API 로드 완료:", params.api);

        if (typeof params.api.setSortModel === "function") {
          params.api.setSortModel([
            { colId: "CATEGORY1", sort: "asc" },
            { colId: "CATEGORY2", sort: "asc" },
          ]);
          params.api.refreshClientSideRowModel();
        } else {
          console.warn("🚨 Warning: `setSortModel` 함수가 존재하지 않습니다!");
        }

        // ✅ 현재 주차 컬럼을 보이게 설정
        params.api.ensureColumnVisible(`WW${currentWeek - 1}_TARGET`, "start");
      }
    }, 500);
  };

  // ✅ 행이 클릭될 때 선택된 행 데이터를 저장
  const onRowClicked = (event) => {
    setSelectedRow(event.data);
  };

  const addRow = () => {
    setRowData((rowData) => [
      ...rowData,
      {
        CATEGORY1: "",
        CATEGORY2: "",
        TARGET: 0,
        WW1: 0,
        WW2: 0,
        WW3: 0,
        WW4: 0,
        REMARKS: "",
      },
    ]);
  };

  const onSave = () => {
    const updateData = [];
    gridApi.forEachNode((node) => updateData.push(node.data));
    const payload = updateData;
    console.log(payload);
  };

  useEffect(() => {
    setRowData(data);
  }, []);
  // ✅ ECharts 그래프 업데이트
  useEffect(() => {
    if (selectedRow && chartRef.current) {
      const myChart = echarts.init(chartRef.current);

      // ✅ 선택된 행 데이터 확인
      console.log("🔍 선택된 행 데이터:", selectedRow);

      // ✅ WW1~WW10의 Target & Result 데이터 추출
      const weeks = Array.from({ length: 10 }, (_, i) => `WW${i + 1}`);
      const targetData = weeks.map(
        (week) => selectedRow[`${week}_TARGET`] || 0
      );
      const resultData = weeks.map(
        (week) => selectedRow[`${week}_RESULT`] || 0
      );

      console.log("🎯 Target 데이터:", targetData);
      console.log("🎯 Result 데이터:", resultData);

      const option = {
        title: {
          text: `${selectedRow.CATEGORY1} - ${selectedRow.CATEGORY2} 트렌드`,
          left: "center",
        },
        tooltip: { trigger: "axis" },
        xAxis: {
          type: "category",
          data: weeks,
        },
        yAxis: { type: "value" },
        series: [
          {
            name: "Target",
            type: "line",
            step: "middle", // ✅ 계단형 그래프 적용
            data: targetData,
            smooth: false, // ✅ 부드러운 곡선 비활성화 (계단형 유지)
            lineStyle: { type: "dashed", color: "blue", width: 2 }, // ✅ 파란색 점선
            itemStyle: { color: "blue" },
          },
          {
            name: "Result",
            type: "line",
            data: resultData,
            smooth: true, // ✅ 부드러운 곡선 적용
            lineStyle: { color: "black", width: 2 }, // ✅ 검정색 실선
            itemStyle: { color: "black" },
          },
        ],
      };

      console.log("🎯 최종 ECharts option:", option);

      myChart.clear();
      myChart.setOption(option);
    }
  }, [selectedRow]);

  return (
    <>
      <div
        className="ag-theme-alpine"
        style={{ height: "500px", width: "100%" }}
      >
        <AgGridReact
          animateRows
          columnDefs={columnDefs}
          rowData={rowData}
          onGridReady={onGridReady}
          gridOptions={{ suppressHorizontalScroll: false }}
          onRowClicked={onRowClicked} // ✅ 행 클릭 이벤트 추가
          defaultColDef={{
            editable: true,
            resizable: true,
            filter: true,
            sortable: true,
          }}
        />
      </div>

      <h3 style={{ textAlign: "center", marginTop: "20px" }}>
        {selectedRow
          ? `${selectedRow.CATEGORY1} - ${selectedRow.CATEGORY2} 트렌드`
          : "데이터를 선택하세요"}
      </h3>

      {/* ✅ ECharts 그래프 추가 */}
      <div
        ref={chartRef}
        style={{ width: "100%", height: "400px", marginTop: "20px" }}
      ></div>
      <Button onClick={addRow}>행추가</Button>
      <Button onClick={onSave}>저장 </Button>
    </>
  );
}

export default App;
